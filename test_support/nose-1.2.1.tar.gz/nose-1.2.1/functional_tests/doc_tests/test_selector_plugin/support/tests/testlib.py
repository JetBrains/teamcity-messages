import unittest

class Base(unittest.TestCase):
    """Use this base class for all tests.
    """
    pass
