"""
>>> True
False
"""
"""
>>> True
False
"""
